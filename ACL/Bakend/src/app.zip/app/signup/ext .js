	
function myfunction()
{ 
var pass1 = document.getElementById("psw").value;
var pass2 = document.getElementById("psw2").value;
 if(pass1!=pass2)
{
	alert("Hello! Passwords do not match!!");		
}
}	
